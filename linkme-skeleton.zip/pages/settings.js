import { useState } from 'react';

export default function Settings() {
  const [language, setLanguage] = useState('he');
  const handleDeleteAccount = () => {
    if (confirm('האם אתה בטוח שברצונך למחוק את החשבון?')) {
      alert('חשבון נמחק (placeholder)');
    }
  };
  return (
    <div className="max-w-md mx-auto p-4 mt-6 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">הגדרות</h2>
      <div className="space-y-4">
        <div>
          <label className="block mb-1 text-sm">שפה</label>
          <select value={language} onChange={(e) => setLanguage(e.target.value)} className="w-full border px-3 py-2 rounded-md">
            <option value="he">עברית</option>
            <option value="en">English</option>
            <option value="ar">العربية</option>
          </select>
        </div>
        <div>
          <label className="block mb-1 text-sm">שינוי סיסמה</label>
          <input type="password" placeholder="סיסמה חדשה" className="w-full border px-3 py-2 rounded-md" />
        </div>
        <button onClick={handleDeleteAccount} className="w-full bg-red-600 text-white py-2 rounded-md hover:bg-red-700">מחק חשבון</button>
      </div>
    </div>
  );
}