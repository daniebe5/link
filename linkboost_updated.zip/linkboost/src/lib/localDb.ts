// A simple local storage-based database for the LinkBoost application.
// This module provides basic CRUD operations for users, profiles, links,
// shouts, messages and follows using the browser's localStorage.  It
// operates purely on the client and is intended as a drop‑in replacement
// for Supabase in offline/demo environments.

// Types
export interface LocalUser {
  id: string
  email: string
  password: string
}

export interface Profile {
  id: string
  userId: string
  username: string
  fullName: string
  bio: string
  profileType: 'personal' | 'business'
  themeBackground: string
  themeButton: string
  avatarUrl: string | null
  socials: {
    tiktok?: string | null
    instagram?: string | null
    youtube?: string | null
    linkedin?: string | null
  }
}

export interface Link {
  id: string
  userId: string
  title: string
  url: string
  icon?: string | null
  order: number
}

export interface Click {
  id: string
  linkId: string
  timestamp: number
}

export interface Shout {
  id: string
  userId: string
  content: string
  mediaUrl: string | null
  expiresAt: number
  createdAt: number
}

export interface Message {
  id: string
  senderId: string
  recipientId: string
  message: string
  createdAt: number
}

export interface Follow {
  followerId: string
  followingId: string
}

// Helpers to get and set arrays in localStorage
function getArray<T>(key: string): T[] {
  if (typeof localStorage === 'undefined') return []
  const raw = localStorage.getItem(key)
  try {
    return raw ? (JSON.parse(raw) as T[]) : []
  } catch {
    return []
  }
}

function setArray<T>(key: string, arr: T[]) {
  if (typeof localStorage === 'undefined') return
  localStorage.setItem(key, JSON.stringify(arr))
}

// USER MANAGEMENT
export function signUp(email: string, password: string): { user: LocalUser | null; error?: string } {
  const users = getArray<LocalUser>('lb_users')
  const existing = users.find((u) => u.email === email)
  if (existing) {
    return { user: null, error: 'Email already exists' }
  }
  const id = Date.now().toString(36) + Math.random().toString(36).substring(2)
  const user: LocalUser = { id, email, password }
  users.push(user)
  setArray('lb_users', users)
  // set current user
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('lb_current_user_id', id)
  }
  return { user }
}

export function signIn(email: string, password: string): { user: LocalUser | null; error?: string } {
  const users = getArray<LocalUser>('lb_users')
  const user = users.find((u) => u.email === email && u.password === password)
  if (!user) {
    return { user: null, error: 'Invalid email or password' }
  }
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem('lb_current_user_id', user.id)
  }
  return { user }
}

export function signOut() {
  if (typeof localStorage === 'undefined') return
  localStorage.removeItem('lb_current_user_id')
}

export function getCurrentUser(): LocalUser | null {
  if (typeof localStorage === 'undefined') return null
  const userId = localStorage.getItem('lb_current_user_id')
  if (!userId) return null
  const users = getArray<LocalUser>('lb_users')
  return users.find((u) => u.id === userId) || null
}

export function getUserById(id: string): LocalUser | null {
  const users = getArray<LocalUser>('lb_users')
  return users.find((u) => u.id === id) || null
}

// Update the password for a given user.  This helper is used by the
// settings page to allow users to change their password.  If the user
// does not exist, the function silently does nothing.  Note: In a real
// database you would hash passwords; this simple implementation stores
// them in plain text for demonstration purposes.
export function updatePassword(userId: string, newPassword: string) {
  const users = getArray<LocalUser>('lb_users')
  const idx = users.findIndex((u) => u.id === userId)
  if (idx >= 0) {
    users[idx] = { ...users[idx], password: newPassword }
    setArray('lb_users', users)
  }
}

// PROFILE MANAGEMENT
export function getProfile(userId: string): Profile | null {
  const profiles = getArray<Profile>('lb_profiles')
  return profiles.find((p) => p.userId === userId) || null
}

export function upsertProfile(profile: Profile) {
  const profiles = getArray<Profile>('lb_profiles')
  const idx = profiles.findIndex((p) => p.id === profile.id)
  if (idx >= 0) {
    profiles[idx] = profile
  } else {
    profiles.push(profile)
  }
  setArray('lb_profiles', profiles)
}

// Generate a unique id for records
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2)
}

// LINKS
export function getLinks(userId: string): Link[] {
  const links = getArray<Link>('lb_links')
  return links.filter((l) => l.userId === userId).sort((a, b) => a.order - b.order)
}

export function addLink(userId: string, link: Omit<Link, 'id' | 'userId'>) {
  const links = getArray<Link>('lb_links')
  const nextOrder = links.filter((l) => l.userId === userId).length
  const newLink: Link = {
    ...link,
    id: generateId(),
    userId,
    order: nextOrder,
  }
  links.push(newLink)
  setArray('lb_links', links)
  return newLink
}

export function deleteLink(linkId: string) {
  let links = getArray<Link>('lb_links')
  links = links.filter((l) => l.id !== linkId)
  setArray('lb_links', links)
}

export function reorderLinks(userId: string, orderedIds: string[]) {
  const links = getArray<Link>('lb_links')
  const updated = links.map((l) => {
    if (l.userId !== userId) return l
    const newOrder = orderedIds.indexOf(l.id)
    return { ...l, order: newOrder >= 0 ? newOrder : l.order }
  })
  setArray('lb_links', updated)
}

// CLICK LOGGING
export function recordClick(linkId: string) {
  const clicks = getArray<Click>('lb_clicks')
  clicks.push({ id: generateId(), linkId, timestamp: Date.now() })
  setArray('lb_clicks', clicks)
}

export function getClickCountsForUser(userId: string): { [linkId: string]: number } {
  const clicks = getArray<Click>('lb_clicks')
  const links = getLinks(userId)
  const counts: { [linkId: string]: number } = {}
  links.forEach((l) => (counts[l.id] = 0))
  clicks.forEach((c) => {
    const link = links.find((l) => l.id === c.linkId)
    if (link) {
      counts[link.id] = (counts[link.id] || 0) + 1
    }
  })
  return counts
}

// SHOUTS
export function addShout(userId: string, content: string, mediaUrl: string | null, expiresInHours: number) {
  const shouts = getArray<Shout>('lb_shouts')
  const now = Date.now()
  const shout: Shout = {
    id: generateId(),
    userId,
    content,
    mediaUrl,
    expiresAt: now + expiresInHours * 3600 * 1000,
    createdAt: now,
  }
  shouts.push(shout)
  setArray('lb_shouts', shouts)
  return shout
}

export function getUserShouts(userId: string): Shout[] {
  const now = Date.now()
  return getArray<Shout>('lb_shouts').filter((s) => s.userId === userId && s.expiresAt > now)
}

export function deleteShout(shoutId: string) {
  let shouts = getArray<Shout>('lb_shouts')
  shouts = shouts.filter((s) => s.id !== shoutId)
  setArray('lb_shouts', shouts)
}

export function getPublicShouts(): (Shout & { profile: Profile | null })[] {
  const now = Date.now()
  const shouts = getArray<Shout>('lb_shouts').filter((s) => s.expiresAt > now)
  return shouts.map((s) => ({ ...s, profile: getProfile(s.userId) }))
}

// MESSAGES
export function addMessage(senderId: string, recipientId: string, message: string) {
  const messages = getArray<Message>('lb_messages')
  messages.push({ id: generateId(), senderId, recipientId, message, createdAt: Date.now() })
  setArray('lb_messages', messages)
}

export function getConversation(userId: string, otherId: string): Message[] {
  return getArray<Message>('lb_messages').filter(
    (m) => (m.senderId === userId && m.recipientId === otherId) || (m.senderId === otherId && m.recipientId === userId),
  ).sort((a, b) => a.createdAt - b.createdAt)
}

// FOLLOWS
export function follow(followerId: string, followingId: string) {
  const follows = getArray<Follow>('lb_follows')
  if (!follows.find((f) => f.followerId === followerId && f.followingId === followingId)) {
    follows.push({ followerId, followingId })
    setArray('lb_follows', follows)
  }
}

export function unfollow(followerId: string, followingId: string) {
  let follows = getArray<Follow>('lb_follows')
  follows = follows.filter((f) => !(f.followerId === followerId && f.followingId === followingId))
  setArray('lb_follows', follows)
}

export function getFollowingIds(followerId: string): string[] {
  return getArray<Follow>('lb_follows')
    .filter((f) => f.followerId === followerId)
    .map((f) => f.followingId)
}

// Utility to get all profiles (for explore)
export function getAllProfiles(): Profile[] {
  return getArray<Profile>('lb_profiles')
}