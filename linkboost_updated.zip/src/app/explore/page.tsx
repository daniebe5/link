"use client"

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/providers/AuthProvider'
import Link from 'next/link'

interface ProfileRow {
  user_id: string
  username: string
  full_name: string | null
  bio: string | null
  avatar_url: string | null
}

export default function ExplorePage() {
  const { user } = useAuth()
  const [profiles, setProfiles] = useState<ProfileRow[]>([])
  const [followingIds, setFollowingIds] = useState<string[]>([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  useEffect(() => {
    if (!user) return
    const fetchData = async () => {
      try {
        const { data: profilesData, error: profilesError } = await supabase
          .from('profiles')
          .select('user_id, username, full_name, bio, avatar_url')
          .neq('user_id', user.id)
        if (profilesError) throw profilesError
        setProfiles(profilesData as ProfileRow[])
        const { data: followData, error: followError } = await supabase
          .from('follows')
          .select('following_id')
          .eq('follower_id', user.id)
        if (followError) throw followError
        const follows = (followData as { following_id: string }[]) || []
        setFollowingIds(follows.map((f) => f.following_id))
      } catch (err) {
        if (err instanceof Error) {
          setErrorMsg(err.message)
        }
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [user])

  const toggleFollow = async (targetId: string) => {
    if (!user) return
    if (followingIds.includes(targetId)) {
      // unfollow
      const { error } = await supabase
        .from('follows')
        .delete()
        .eq('follower_id', user.id)
        .eq('following_id', targetId)
      if (error) setErrorMsg(error.message)
      else setFollowingIds((prev) => prev.filter((id) => id !== targetId))
    } else {
      const { error } = await supabase.from('follows').insert({ follower_id: user.id, following_id: targetId })
      if (error) setErrorMsg(error.message)
      else setFollowingIds((prev) => [...prev, targetId])
    }
  }
  const filtered = query
    ? profiles.filter((p) =>
        p.username.toLowerCase().includes(query.toLowerCase()) ||
        (p.full_name ?? '').toLowerCase().includes(query.toLowerCase()) ||
        (p.bio ?? '').toLowerCase().includes(query.toLowerCase()),
      )
    : profiles
  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Explore</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <input
          type="text"
          placeholder="Search users..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="mb-4 w-full rounded-md border border-gray-300 p-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
        <div className="space-y-4">
          {filtered.map((profile) => (
            <div key={profile.user_id} className="bg-white p-4 rounded-md shadow flex justify-between items-center">
              <div className="flex items-center">
                {profile.avatar_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={profile.avatar_url} alt="avatar" className="w-10 h-10 rounded-full mr-3 object-cover" />
                )}
                <div>
                  <Link href={`/${profile.username}`} className="font-semibold text-indigo-600 hover:underline">
                    {profile.full_name || profile.username}
                  </Link>
                  {profile.bio && <p className="text-sm text-gray-500">{profile.bio}</p>}
                </div>
              </div>
              <button
                onClick={() => toggleFollow(profile.user_id)}
                className={`px-4 py-1 rounded-md text-sm font-medium border ${
                  followingIds.includes(profile.user_id)
                    ? 'bg-gray-200 text-gray-800'
                    : 'bg-indigo-600 text-white'
                }`}
              >
                {followingIds.includes(profile.user_id) ? 'Following' : 'Follow'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}