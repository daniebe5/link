"use client"

import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import * as db from '@/lib/localDb'
import { useAuth } from '@/providers/AuthProvider'
import {
  DndContext,
  closestCenter,
  DragEndEvent,
} from '@dnd-kit/core'
import {
  arrayMove,
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'

interface LinkRow {
  id: string
  userId: string
  title: string
  url: string
  icon: string | null | undefined
  order: number
}

interface LinkForm {
  title: string
  url: string
  icon: string
}

function SortableItem({ link, onDelete }: { link: LinkRow; onDelete: (id: string) => void }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: link.id })
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  }
  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white p-4 rounded-md shadow flex justify-between items-center mb-3"
      {...attributes}
      {...listeners}
    >
      <div>
        <p className="font-semibold">{link.title}</p>
        <p className="text-sm text-gray-600 break-all">{link.url}</p>
      </div>
      <button
        onClick={() => onDelete(link.id)}
        className="text-red-600 hover:text-red-800 text-sm"
      >
        Delete
      </button>
    </div>
  )
}

export default function LinksPage() {
  const { user } = useAuth()
  const [links, setLinks] = useState<LinkRow[]>([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<LinkForm>()
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!user) return
    const fetchLinks = () => {
      try {
        const data = db.getLinks(user.id)
        setLinks(data as LinkRow[])
      } catch (err) {
        if (err instanceof Error) setErrorMsg(err.message)
      } finally {
        setLoading(false)
      }
    }
    fetchLinks()
  }, [user])

  const onSubmit = async (form: LinkForm) => {
    if (!user) return
    setSaving(true)
    try {
      const newLink = db.addLink(user.id, {
        title: form.title,
        url: form.url,
        icon: form.icon || null,
        order: 0, // order is handled internally
      })
      setLinks((prev) => [...prev, newLink as LinkRow])
      reset()
    } catch (err) {
      if (err instanceof Error) setErrorMsg(err.message)
    } finally {
      setSaving(false)
    }
  }

  const deleteLink = async (id: string) => {
    try {
      db.deleteLink(id)
      setLinks((prev) => prev.filter((l) => l.id !== id))
    } catch (err) {
      if (err instanceof Error) setErrorMsg(err.message)
    }
  }

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event
    if (!over || active.id === over.id) return
    // If the user is not defined, abort reordering.  This avoids
    // TypeScript errors about possibly null user.id and prevents runtime
    // exceptions when unauthenticated users trigger drag events.
    if (!user) return
    const oldIndex = links.findIndex((l) => l.id === active.id)
    const newIndex = links.findIndex((l) => l.id === over.id)
    const newLinks = arrayMove(links, oldIndex, newIndex).map((link, index) => ({
      ...link,
      order: index,
    }))
    setLinks(newLinks)
    try {
      const orderedIds = newLinks.map((l) => l.id)
      db.reorderLinks(user.id, orderedIds)
    } catch (err) {
      if (err instanceof Error) setErrorMsg(err.message)
    }
  }

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) {
    return <div className="p-6">Loading...</div>
  }
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Manage Links</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <form onSubmit={handleSubmit(onSubmit)} className="mb-6 space-y-2">
          <div>
            <input
              type="text"
              placeholder="Link title"
              {...register('title', { required: 'Title is required' })}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm mb-2"
            />
            {errors.title && <p className="text-red-500 text-xs">{errors.title.message}</p>}
          </div>
          <div>
            <input
              type="url"
              placeholder="https://example.com"
              {...register('url', { required: 'URL is required' })}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm mb-2"
            />
            {errors.url && <p className="text-red-500 text-xs">{errors.url.message}</p>}
          </div>
          <div>
            <input
              type="text"
              placeholder="Icon (optional, e.g. https://... or emoji)"
              {...register('icon')}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm mb-2"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none"
          >
            {saving ? 'Adding...' : 'Add Link'}
          </button>
        </form>
        <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={links.map((l) => l.id)} strategy={verticalListSortingStrategy}>
            {links.map((link) => (
              <SortableItem key={link.id} link={link} onDelete={deleteLink} />
            ))}
          </SortableContext>
        </DndContext>
      </div>
    </div>
  )
}