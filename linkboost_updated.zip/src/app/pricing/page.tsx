"use client"

import { loadStripe } from '@stripe/stripe-js'
import { useState } from 'react'

// Pricing details for the three plans.  You can adjust pricing and features
// here.  In a real implementation you would fetch products from Stripe.
const plans = [
  {
    name: 'Free',
    price: 0,
    description: 'Basic features to get started',
    features: ['1 profile', 'Basic link analytics', 'Limited support'],
    priceId: null,
  },
  {
    name: 'Pro',
    price: 9,
    description: 'Advanced analytics and customizations',
    features: ['Everything in Free', 'Advanced analytics', 'Priority support'],
    priceId: 'price_pro',
  },
  {
    name: 'Business',
    price: 29,
    description: 'Multiple profiles and team features',
    features: ['Everything in Pro', 'Multiple profiles', 'Team collaboration'],
    priceId: 'price_business',
  },
]

export default function PricingPage() {
  const [loadingId, setLoadingId] = useState<string | null>(null)
  const handleCheckout = async (priceId: string | null) => {
    if (!priceId) return
    setLoadingId(priceId)
    const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '')
    if (!stripe) return
    // In a real implementation you would create a checkout session via your
    // server (e.g. an API route) and then redirect.  For this demo we
    // construct a URL with the priceId as a query param.  The backend
    // should validate the price and create a session.
    const res = await fetch('/api/create-checkout-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ priceId }),
    })
    const session = await res.json()
    await stripe.redirectToCheckout({ sessionId: session.id })
    setLoadingId(null)
  }
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-5xl mx-auto text-center">
        <h2 className="text-3xl font-bold mb-6">Pricing Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div key={plan.name} className="bg-white rounded-lg shadow p-6 flex flex-col">
              <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
              <p className="text-4xl font-bold mb-4">
                {plan.price === 0 ? 'Free' : `$${plan.price}`}
                {plan.price !== 0 && <span className="text-sm">/month</span>}
              </p>
              <p className="mb-4 text-gray-600">{plan.description}</p>
              <ul className="mb-6 flex-1 list-disc list-inside text-left">
                {plan.features.map((f) => (
                  <li key={f}>{f}</li>
                ))}
              </ul>
              {plan.price === 0 ? (
                <button
                  className="mt-auto w-full py-2 px-4 rounded-md border border-indigo-600 text-indigo-600 hover:bg-indigo-50"
                >
                  Current Plan
                </button>
              ) : (
                <button
                  onClick={() => handleCheckout(plan.priceId)}
                  disabled={loadingId === plan.priceId}
                  className="mt-auto w-full py-2 px-4 rounded-md text-white"
                  style={{ backgroundColor: loadingId === plan.priceId ? '#A5B4FC' : '#6366F1' }}
                >
                  {loadingId === plan.priceId ? 'Processing...' : 'Upgrade'}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}