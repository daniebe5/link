"use client"

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import * as db from '@/lib/localDb'

// Define a user type based on our localDb implementation.
type AuthUser = db.LocalUser | null

interface AuthContextProps {
  user: AuthUser
  signIn: (email: string, password: string) => { error?: string }
  signUp: (email: string, password: string) => { error?: string }
  signOut: () => void
}

const AuthContext = createContext<AuthContextProps>({
  user: null,
  // Default implementations are no-ops; real implementations are provided in the provider.
  signIn: () => ({}),
  signUp: () => ({}),
  signOut: () => {},
})

interface AuthProviderProps {
  children: ReactNode
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<db.LocalUser | null>(null)

  // On mount, initialize user from local storage.
  useEffect(() => {
    const current = db.getCurrentUser()
    setUser(current)
  }, [])

  const signIn = (email: string, password: string) => {
    const { user: u, error } = db.signIn(email, password)
    if (u) {
      setUser(u)
    }
    return { error }
  }

  const signUp = (email: string, password: string) => {
    const { user: u, error } = db.signUp(email, password)
    if (u) {
      setUser(u)
    }
    return { error }
  }

  const signOut = () => {
    db.signOut()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}