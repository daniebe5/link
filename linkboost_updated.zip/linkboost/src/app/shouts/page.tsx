"use client"

import { useEffect, useState } from 'react'
// Use local storage helpers to fetch public shouts.  This eliminates
// dependencies on Supabase for the public feed.
import { getPublicShouts } from '@/lib/localDb'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'

dayjs.extend(relativeTime)

interface PublicShout {
  id: string
  content: string
  mediaUrl: string | null
  expiresAt: number
  createdAt: number
  profile: {
    fullName: string
    avatarUrl: string | null
    username: string
  } | null
}

export default function PublicShoutsPage() {
  const [shouts, setShouts] = useState<PublicShout[]>([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  useEffect(() => {
    // Load public shouts from local storage.  Each shout includes a profile
    // object with the creator's details or null if no profile exists.
    try {
      const data = getPublicShouts()
      setShouts(
        data.map((item) => ({
          id: item.id,
          content: item.content,
          mediaUrl: item.mediaUrl,
          expiresAt: item.expiresAt,
          createdAt: item.createdAt,
          profile: item.profile
            ? {
                fullName: item.profile.fullName,
                avatarUrl: item.profile.avatarUrl,
                username: item.profile.username,
              }
            : null,
        }))
      )
    } catch (err) {
      if (err instanceof Error) setErrorMsg(err.message)
      else setErrorMsg(String(err))
    } finally {
      setLoading(false)
    }
  }, [])
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Public Shouts</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        {shouts.length === 0 ? (
          <p>No shouts available.</p>
        ) : (
          <div className="space-y-4">
            {shouts.map((shout) => (
              <div key={shout.id} className="bg-white p-4 rounded-md shadow">
                <div className="flex items-center mb-2">
                  {shout.profile?.avatarUrl && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={shout.profile.avatarUrl}
                      alt="avatar"
                      className="w-8 h-8 rounded-full mr-2 object-cover"
                    />
                  )}
                  <div>
                    {shout.profile && (
                      <a
                        href={`/${shout.profile.username}`}
                        className="font-semibold text-indigo-600 hover:underline"
                      >
                        {shout.profile.fullName || shout.profile.username}
                      </a>
                    )}
                    <p className="text-xs text-gray-500">
                      {dayjs(shout.createdAt).fromNow()}
                    </p>
                  </div>
                </div>
                <p className="mb-2 whitespace-pre-wrap">{shout.content}</p>
                {shout.mediaUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={shout.mediaUrl} alt="media" className="max-h-64 w-auto rounded-md mb-2" />
                )}
                <p className="text-xs text-gray-500">
                  Expires {dayjs(shout.expiresAt).fromNow(true)} left
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}