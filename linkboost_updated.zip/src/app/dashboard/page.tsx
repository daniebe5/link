"use client"

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/providers/AuthProvider'

interface Profile {
  id: string
  user_id: string
  username: string
  full_name: string | null
  bio: string | null
  profile_type: string | null
  avatar_url: string | null
}

export default function DashboardPage() {
  const { user } = useAuth()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')

  useEffect(() => {
    if (user) {
      fetchProfile()
    } else {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user!.id)
        .single()
      if (error && error.code !== 'PGRST116') {
        throw error
      }
      setProfile(data)
    } catch (err) {
      if (err instanceof Error) {
        setErrorMsg(err.message)
      }
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
        <p>
          <Link href="/login" className="text-indigo-600 hover:underline">
            Go to login
          </Link>
        </p>
      </div>
    )
  }

  if (loading) {
    return <div className="p-6">Loading...</div>
  }

  if (errorMsg) {
    return <div className="p-6 text-red-500">Error: {errorMsg}</div>
  }

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
        {profile ? (
          <div className="space-y-6">
            <p className="text-lg">
              Welcome back,{' '}
              <span className="font-semibold">
                {profile.full_name || user.email}
              </span>
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link
                href="/dashboard/profile"
                className="block p-6 rounded-lg bg-white shadow hover:bg-gray-50"
              >
                <h3 className="text-xl font-semibold mb-2">Edit Profile</h3>
                <p className="text-gray-600">Update your personal or business details and appearance.</p>
              </Link>
              <Link
                href="/dashboard/links"
                className="block p-6 rounded-lg bg-white shadow hover:bg-gray-50"
              >
                <h3 className="text-xl font-semibold mb-2">Manage Links</h3>
                <p className="text-gray-600">Add and organize your link-in-bio content.</p>
              </Link>
              <Link
                href="/dashboard/analytics"
                className="block p-6 rounded-lg bg-white shadow hover:bg-gray-50"
              >
                <h3 className="text-xl font-semibold mb-2">Analytics</h3>
                <p className="text-gray-600">View clicks and engagement statistics.</p>
              </Link>
              <Link
                href="/dashboard/shouts"
                className="block p-6 rounded-lg bg-white shadow hover:bg-gray-50"
              >
                <h3 className="text-xl font-semibold mb-2">Shouts</h3>
                <p className="text-gray-600">Create and manage temporary shout posts.</p>
              </Link>
              <Link
                href="/dashboard/settings"
                className="block p-6 rounded-lg bg-white shadow hover:bg-gray-50"
              >
                <h3 className="text-xl font-semibold mb-2">Settings</h3>
                <p className="text-gray-600">Account preferences, subscription and security.</p>
              </Link>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <p className="text-lg">
              Welcome! Let&apos;s get your profile set up.
            </p>
            <Link
              href="/dashboard/profile"
              className="inline-block rounded-md bg-indigo-600 py-2 px-4 text-white hover:bg-indigo-700"
            >
              Create your profile
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}