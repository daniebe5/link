"use client"

import { useEffect, useState, ChangeEvent } from 'react'
import { useForm } from 'react-hook-form'
// Import local database helpers for managing shouts stored in localStorage.
import { addShout, getUserShouts, deleteShout as removeShout } from '@/lib/localDb'
import { useAuth } from '@/providers/AuthProvider'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'

// Extend dayjs with the relativeTime plugin once at module load.  Without
// extension, the `fromNow` helper used below will throw.  See
// https://day.js.org/docs/en/plugin/loading-into-custom-build for details.
dayjs.extend(relativeTime)

interface ShoutRow {
  id: string
  userId: string
  content: string
  mediaUrl: string | null
  expiresAt: number
  createdAt: number
}

interface ShoutForm {
  content: string
  expires_in: number
}

export default function ShoutsPage() {
  const { user } = useAuth()
  const [shouts, setShouts] = useState<ShoutRow[]>([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ShoutForm>({ defaultValues: { expires_in: 24 } })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!user) return
    // Load active shouts from local storage.  We use dayjs for relative time
    // display but the underlying data comes from localDb.  The shouts are
    // already filtered by expiration in the helper.
    const shouts = getUserShouts(user.id)
    // Transform into the ShoutRow shape expected by this component.
    setShouts(shouts.map((s) => ({
      id: s.id,
      userId: s.userId,
      content: s.content,
      mediaUrl: s.mediaUrl,
      expiresAt: s.expiresAt,
      createdAt: s.createdAt,
    })))
    setLoading(false)
  }, [user])

  // Convert a file to a Data URL for storage in localStorage.  Returns a
  // promise that resolves with the base64 representation.
  const fileToDataUrl = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onloadend = () => {
        resolve(reader.result as string)
      }
      reader.onerror = reject
      reader.readAsDataURL(file)
    })

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0]
    if (selected) {
      setFile(selected)
    }
  }

  const onSubmit = async (form: ShoutForm) => {
    if (!user) return
    setSaving(true)
    let media: string | null = null
    if (file) {
      try {
        media = await fileToDataUrl(file)
      } catch (err) {
        console.error(err)
        setErrorMsg('Failed to read media file')
      }
    }
    try {
      const shout = addShout(user.id, form.content, media, form.expires_in)
      // Prepend the new shout to the list
      setShouts((prev) => [
        {
          id: shout.id,
          userId: shout.userId,
          content: shout.content,
          mediaUrl: shout.mediaUrl,
          expiresAt: shout.expiresAt,
          createdAt: shout.createdAt,
        },
        ...prev,
      ])
      reset({ content: '', expires_in: form.expires_in })
      setFile(null)
    } catch (err) {
      if (err instanceof Error) setErrorMsg(err.message)
    }
    setSaving(false)
  }

  const deleteShout = async (id: string) => {
    try {
      removeShout(id)
      setShouts((prev) => prev.filter((s) => s.id !== id))
    } catch (err) {
      if (err instanceof Error) setErrorMsg(err.message)
    }
  }

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">My Shouts</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <form onSubmit={handleSubmit(onSubmit)} className="mb-6 space-y-2 bg-white p-4 rounded-md shadow">
          <div>
            <textarea
              {...register('content', { required: 'Content is required' })}
              rows={3}
              placeholder="What's on your mind?"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm mb-2"
            />
            {errors.content && <p className="text-red-500 text-xs">{errors.content.message}</p>}
          </div>
          <div>
            <input type="file" accept="image/*,video/*" onChange={onFileChange} className="text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Expires in (hours)</label>
            <input
              type="number"
              {...register('expires_in', { required: true, min: 1, max: 168 })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
          >
            {saving ? 'Posting...' : 'Post Shout'}
          </button>
        </form>
        <div className="space-y-4">
          {shouts.length === 0 ? (
            <p>No shouts yet.</p>
          ) : (
            shouts.map((shout) => (
              <div key={shout.id} className="bg-white p-4 rounded-md shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="mb-2 whitespace-pre-wrap">{shout.content}</p>
                    {shout.mediaUrl && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={shout.mediaUrl} alt="shout media" className="max-h-64 w-auto rounded-md mb-2" />
                    )}
                    <p className="text-sm text-gray-500">
                      Expires {dayjs(shout.expiresAt).fromNow(true)} left
                    </p>
                  </div>
                  <button
                    onClick={() => deleteShout(shout.id)}
                    className="text-red-500 text-sm hover:text-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}