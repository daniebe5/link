"use client"

import { useEffect, useState, ChangeEvent } from 'react'
import { useForm } from 'react-hook-form'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/providers/AuthProvider'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'

// Extend dayjs with the relativeTime plugin once at module load.  Without
// extension, the `fromNow` helper used below will throw.  See
// https://day.js.org/docs/en/plugin/loading-into-custom-build for details.
dayjs.extend(relativeTime)

interface ShoutRow {
  id: string
  user_id: string
  content: string
  media_url: string | null
  expires_at: string
  created_at: string
}

interface ShoutForm {
  content: string
  expires_in: number
}

export default function ShoutsPage() {
  const { user } = useAuth()
  const [shouts, setShouts] = useState<ShoutRow[]>([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ShoutForm>({ defaultValues: { expires_in: 24 } })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!user) return
    const fetchShouts = async () => {
      const now = dayjs().toISOString()
      const { data, error } = await supabase
        .from('shouts')
        .select('*')
        .eq('user_id', user.id)
        .gt('expires_at', now)
        .order('created_at', { ascending: false })
      if (error) setErrorMsg(error.message)
      else setShouts(data as ShoutRow[])
      setLoading(false)
    }
    fetchShouts()
  }, [user])

  const uploadMedia = async (file: File): Promise<string | null> => {
    const filePath = `${user!.id}/${Date.now()}_${file.name}`
    const { error } = await supabase.storage
      .from('shouts')
      .upload(filePath, file, { cacheControl: '3600', upsert: false })
    if (error) {
      setErrorMsg(error.message)
      return null
    }
    const { data } = supabase.storage.from('shouts').getPublicUrl(filePath)
    return data.publicUrl
  }

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0]
    if (selected) {
      setFile(selected)
    }
  }

  const onSubmit = async (form: ShoutForm) => {
    if (!user) return
    setSaving(true)
    let mediaUrl: string | null = null
    if (file) {
      const uploaded = await uploadMedia(file)
      if (uploaded) mediaUrl = uploaded
    }
    const expiresAt = dayjs().add(form.expires_in, 'hour').toISOString()
    const { data, error } = await supabase.from('shouts').insert({
      user_id: user.id,
      content: form.content,
      media_url: mediaUrl,
      expires_at: expiresAt,
    }).select()
    if (error) {
      setErrorMsg(error.message)
    } else if (data) {
      setShouts((prev) => [data[0] as ShoutRow, ...prev])
      reset({ content: '', expires_in: form.expires_in })
      setFile(null)
    }
    setSaving(false)
  }

  const deleteShout = async (id: string) => {
    const { error } = await supabase.from('shouts').delete().eq('id', id)
    if (error) setErrorMsg(error.message)
    else setShouts((prev) => prev.filter((s) => s.id !== id))
  }

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">My Shouts</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <form onSubmit={handleSubmit(onSubmit)} className="mb-6 space-y-2 bg-white p-4 rounded-md shadow">
          <div>
            <textarea
              {...register('content', { required: 'Content is required' })}
              rows={3}
              placeholder="What's on your mind?"
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm mb-2"
            />
            {errors.content && <p className="text-red-500 text-xs">{errors.content.message}</p>}
          </div>
          <div>
            <input type="file" accept="image/*,video/*" onChange={onFileChange} className="text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Expires in (hours)</label>
            <input
              type="number"
              {...register('expires_in', { required: true, min: 1, max: 168 })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
          >
            {saving ? 'Posting...' : 'Post Shout'}
          </button>
        </form>
        <div className="space-y-4">
          {shouts.length === 0 ? (
            <p>No shouts yet.</p>
          ) : (
            shouts.map((shout) => (
              <div key={shout.id} className="bg-white p-4 rounded-md shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="mb-2 whitespace-pre-wrap">{shout.content}</p>
                    {shout.media_url && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={shout.media_url} alt="shout media" className="max-h-64 w-auto rounded-md mb-2" />
                    )}
                    <p className="text-sm text-gray-500">
                      Expires {dayjs(shout.expires_at).fromNow(true)} left
                    </p>
                  </div>
                  <button
                    onClick={() => deleteShout(shout.id)}
                    className="text-red-500 text-sm hover:text-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}