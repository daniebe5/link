import { useState } from 'react';

export default function Links() {
  const [links, setLinks] = useState([]);
  const [newLink, setNewLink] = useState({ name: '', url: '' });
  const handleAdd = (e) => {
    e.preventDefault();
    setLinks([...links, { ...newLink }]);
    setNewLink({ name: '', url: '' });
  };
  const handleDelete = (index) => {
    setLinks(links.filter((_, i) => i !== index));
  };
  return (
    <div className="max-w-2xl mx-auto p-4 mt-6 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">ניהול קישורים</h2>
      <form onSubmit={handleAdd} className="space-y-4 mb-6">
        <div>
          <label className="block mb-1 text-sm">שם הקישור</label>
          <input type="text" value={newLink.name} onChange={(e) => setNewLink({ ...newLink, name: e.target.value })} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <div>
          <label className="block mb-1 text-sm">כתובת URL</label>
          <input type="url" value={newLink.url} onChange={(e) => setNewLink({ ...newLink, url: e.target.value })} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <button type="submit" className="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">הוסף קישור</button>
      </form>
      <ul className="space-y-2">
        {links.map((link, index) => (
          <li key={index} className="flex justify-between items-center border p-2 rounded-md">
            <a href={link.url} target="_blank" className="text-blue-600 underline">{link.name}</a>
            <button onClick={() => handleDelete(index)} className="text-red-600 hover:underline">מחק</button>
          </li>
        ))}
      </ul>
    </div>
  );
}