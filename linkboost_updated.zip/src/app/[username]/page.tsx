"use client"

import { notFound } from 'next/navigation'
import { useEffect, useState, useRef } from 'react'
import { useParams } from 'next/navigation'
import { supabase } from '@/lib/supabaseClient'
import { QRCodeCanvas } from 'qrcode.react'
import Link from 'next/link'

// We will render social share buttons using simple anchor tags.  Each button
// links to the corresponding share endpoint (WhatsApp, Facebook, X, Telegram)
// with the profile URL encoded.  Dynamic imports of icon libraries (such as
// lucide-react) are avoided to keep bundle size small and because not all
// platforms have dedicated icons in that library.

interface Socials {
  tiktok?: string | null
  instagram?: string | null
  youtube?: string | null
  linkedin?: string | null
  [key: string]: string | null | undefined
}

interface ProfileRow {
  id: string
  user_id: string
  username: string
  full_name: string | null
  bio: string | null
  avatar_url: string | null
  theme_background: string | null
  theme_button: string | null
  socials: Socials | null
}

interface LinkRow {
  id: string
  title: string
  url: string
  icon: string | null
  order: number
}

export default function PublicProfilePage() {
  const params = useParams<{ username: string }>()
  const username = params?.username
  const [profile, setProfile] = useState<ProfileRow | null>(null)
  const [links, setLinks] = useState<LinkRow[]>([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const qrRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const fetchData = async () => {
      if (!username) return
      try {
        const { data: profileData, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('username', username)
          .single()
        if (profileError) throw profileError
        setProfile(profileData as ProfileRow)
        const { data: linksData, error: linksError } = await supabase
          .from('links')
          .select('*')
          .eq('user_id', profileData.user_id)
          .order('order', { ascending: true })
        if (linksError) throw linksError
        setLinks(linksData as LinkRow[])
      } catch (err) {
        if (err instanceof Error) {
          setErrorMsg(err.message)
        }
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [username])

  if (loading) return <div className="p-6">Loading...</div>
  if (!profile) return notFound()

  const bg = profile.theme_background || '#ffffff'
  const btn = profile.theme_button || '#6366f1'

  // Compute the public URL for this profile and encode it for use in share links.
  const profileUrl = `${process.env.NEXT_PUBLIC_SITE_URL}/${profile.username}`
  const encodedUrl = encodeURIComponent(profileUrl)
  const encodedTitle = encodeURIComponent(profile.full_name || profile.username)

  const handleLinkClick = async (link: LinkRow) => {
    // Record the click in the background. We await this call inside a try/catch
    // to avoid using `.catch()` directly on the promise, which is not part of the
    // returned type from Supabase and causes a TS error. Errors are ignored.
    try {
      await supabase.from('clicks').insert({ link_id: link.id })
    } catch {
      // Ignore any errors when logging the click
    }
    // Open the link in a new tab regardless of the logging result
    window.open(link.url, '_blank')
  }

  const downloadQr = () => {
    const canvas = qrRef.current?.querySelector('canvas')
    if (!canvas) return
    const url = canvas.toDataURL('image/png')
    const a = document.createElement('a')
    a.href = url
    a.download = `${username}_qr.png`
    a.click()
  }

  return (
    <div
      className="min-h-screen flex flex-col items-center"
      style={{ backgroundColor: bg }}
    >
      <div className="max-w-md w-full px-4 py-8 text-center">
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        {profile.avatar_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={profile.avatar_url}
            alt="Avatar"
            className="w-24 h-24 mx-auto rounded-full mb-4 object-cover"
          />
        )}
        <h1 className="text-3xl font-bold mb-2" style={{ color: btn }}>
          {profile.full_name || profile.username}
        </h1>
        {profile.bio && <p className="text-gray-700 mb-4">{profile.bio}</p>}
        <div className="space-y-3 mb-6">
          {links.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link)}
              style={{ backgroundColor: btn }}
              className="w-full block py-3 px-4 rounded-md text-white font-medium hover:opacity-90"
            >
              {link.title}
            </button>
          ))}
        </div>
        {/* Social icons */}
        {profile.socials && (
          <div className="flex justify-center space-x-4 mb-6">
            {profile.socials.tiktok && (
              <a href={profile.socials.tiktok} target="_blank" rel="noopener noreferrer" className="text-xl" aria-label="TikTok">
                <span>🎵</span>
              </a>
            )}
            {profile.socials.instagram && (
              <a href={profile.socials.instagram} target="_blank" rel="noopener noreferrer" className="text-xl" aria-label="Instagram">
                <span>📸</span>
              </a>
            )}
            {profile.socials.youtube && (
              <a href={profile.socials.youtube} target="_blank" rel="noopener noreferrer" className="text-xl" aria-label="YouTube">
                <span>▶️</span>
              </a>
            )}
            {profile.socials.linkedin && (
              <a href={profile.socials.linkedin} target="_blank" rel="noopener noreferrer" className="text-xl" aria-label="LinkedIn">
                <span>💼</span>
              </a>
            )}
          </div>
        )}
        {/* QR code section */}
        <div className="mt-8 text-center">
          <h3 className="text-lg font-semibold mb-2">QR Code</h3>
          <div ref={qrRef} className="inline-block bg-white p-2 rounded-md shadow">
            <QRCodeCanvas value={`${process.env.NEXT_PUBLIC_SITE_URL}/${profile.username}`} size={150} />
          </div>
          <div>
            <button
              onClick={downloadQr}
              className="mt-2 inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white"
              style={{ backgroundColor: btn }}
            >
              Download QR
            </button>
          </div>
        </div>

        {/* Share buttons */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-2">Share this profile</h3>
          <div className="flex flex-wrap justify-center gap-2">
            <a
              href={`https://api.whatsapp.com/send?text=${encodedTitle}%20-%20${encodedUrl}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-3 py-2 rounded-md text-sm font-medium text-white"
              style={{ backgroundColor: btn }}
            >
              WhatsApp
            </a>
            <a
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-3 py-2 rounded-md text-sm font-medium text-white"
              style={{ backgroundColor: btn }}
            >
              Facebook
            </a>
            <a
              href={`https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-3 py-2 rounded-md text-sm font-medium text-white"
              style={{ backgroundColor: btn }}
            >
              X
            </a>
            <a
              href={`https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-3 py-2 rounded-md text-sm font-medium text-white"
              style={{ backgroundColor: btn }}
            >
              Telegram
            </a>
          </div>
        </div>

        {/* Advertising banner for free plan users */}
        {/* The specification calls for an advertisement strip to appear on free accounts.  */}
        {/* In lieu of a subscription plan field on the profile, we show this banner by default. */}
        <div className="mt-8 p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 rounded-md">
          <p className="mb-2 font-semibold">Upgrade to Pro</p>
          <p className="text-sm">
            Unlock advanced analytics and customization by upgrading your account.{' '}
            <Link href="/pricing" className="underline">
              View plans
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}