import Link from 'next/link';

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center">
      <div className="py-20 px-4">
        <h1 className="text-4xl font-bold mb-4">ברוך הבא ל-LinkMe</h1>
        <p className="mb-8">הפלטפורמה האולטימטיבית לניהול קישורים, שיתוף, אנליטיקות ופרופילים.</p>
        <div className="space-x-4">
          <Link href="/signup" className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700">הרשמה</Link>
          <Link href="/login" className="bg-gray-200 text-gray-700 px-6 py-3 rounded-md hover:bg-gray-300">התחברות</Link>
        </div>
      </div>
    </div>
  );
}