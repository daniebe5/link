"use client"

import { useEffect, useState } from 'react'
// Use localDb helpers for exploring and following profiles
import { getAllProfiles, getFollowingIds, follow, unfollow } from '@/lib/localDb'
import { useAuth } from '@/providers/AuthProvider'
import Link from 'next/link'

interface ProfileRow {
  userId: string
  username: string
  fullName: string
  bio: string
  avatarUrl: string | null
}

export default function ExplorePage() {
  const { user } = useAuth()
  const [profiles, setProfiles] = useState<ProfileRow[]>([])
  const [followingIds, setFollowingIds] = useState<string[]>([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  useEffect(() => {
    if (!user) return
    const fetchData = async () => {
      try {
        // Load all profiles and filter out the current user
        const all = getAllProfiles().filter((p) => p.userId !== user.id)
        setProfiles(
          all.map((p) => ({
            userId: p.userId,
            username: p.username,
            fullName: p.fullName,
            bio: p.bio,
            avatarUrl: p.avatarUrl,
          }))
        )
        // Load following ids for the current user
        setFollowingIds(getFollowingIds(user.id))
      } catch (err) {
        if (err instanceof Error) {
          setErrorMsg(err.message)
        }
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [user])

  const toggleFollow = async (targetId: string) => {
    if (!user) return
    if (followingIds.includes(targetId)) {
      // unfollow
      // Remove the follow relationship from local storage
      unfollow(user.id, targetId)
      setFollowingIds((prev) => prev.filter((id) => id !== targetId))
    } else {
      // Add a new follow relationship
      follow(user.id, targetId)
      setFollowingIds((prev) => [...prev, targetId])
    }
  }
  const filtered = query
    ? profiles.filter((p) =>
        p.username.toLowerCase().includes(query.toLowerCase()) ||
        p.fullName.toLowerCase().includes(query.toLowerCase()) ||
        p.bio.toLowerCase().includes(query.toLowerCase()),
      )
    : profiles
  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Explore</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <input
          type="text"
          placeholder="Search users..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="mb-4 w-full rounded-md border border-gray-300 p-2 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
        />
        <div className="space-y-4">
          {filtered.map((profile) => (
            <div key={profile.userId} className="bg-white p-4 rounded-md shadow flex justify-between items-center">
              <div className="flex items-center">
                {profile.avatarUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={profile.avatarUrl} alt="avatar" className="w-10 h-10 rounded-full mr-3 object-cover" />
                )}
                <div>
                  <Link href={`/${profile.username}`} className="font-semibold text-indigo-600 hover:underline">
                    {profile.fullName || profile.username}
                  </Link>
                  {profile.bio && <p className="text-sm text-gray-500">{profile.bio}</p>}
                </div>
              </div>
              <button
                onClick={() => toggleFollow(profile.userId)}
                className={`px-4 py-1 rounded-md text-sm font-medium border ${
                  followingIds.includes(profile.userId)
                    ? 'bg-gray-200 text-gray-800'
                    : 'bg-indigo-600 text-white'
                }`}
              >
                {followingIds.includes(profile.userId) ? 'Following' : 'Follow'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}