"use client"

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/providers/AuthProvider'

interface UserRow {
  id: string
  profiles: {
    username: string
    full_name: string | null
    avatar_url: string | null
  }
}
interface MessageRow {
  id: string
  sender_id: string
  recipient_id: string
  message: string
  created_at: string
}

export default function MessagesPage() {
  const { user } = useAuth()
  const [otherUsers, setOtherUsers] = useState<UserRow[]>([])
  const [selected, setSelected] = useState<UserRow | null>(null)
  const [messages, setMessages] = useState<MessageRow[]>([])
  const [newMsg, setNewMsg] = useState('')
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  useEffect(() => {
    if (!user) return
    const fetchUsers = async () => {
      // fetch other users with their profiles
      const { data, error } = await supabase
        .from('profiles')
        .select('user_id, username, full_name, avatar_url')
        .neq('user_id', user.id)
      if (error) {
        setErrorMsg(error.message)
      } else {
        setOtherUsers(
          (data as { user_id: string; username: string; full_name: string | null; avatar_url: string | null }[]).map(
            (p) => ({
              id: p.user_id,
              profiles: { username: p.username, full_name: p.full_name, avatar_url: p.avatar_url },
            }),
          ),
        )
      }
      setLoading(false)
    }
    fetchUsers()
  }, [user])

  useEffect(() => {
    if (!user || !selected) return
    const fetchMessages = async () => {
      const { data, error } = await supabase
        .from('messages')
        .select('id,sender_id,recipient_id,message,created_at')
        .or(`and(sender_id.eq.${user.id},recipient_id.eq.${selected.id}),and(sender_id.eq.${selected.id},recipient_id.eq.${user.id})`)
        .order('created_at', { ascending: true })
      if (error) {
        setErrorMsg(error.message)
      } else {
        setMessages(data as MessageRow[])
      }
    }
    fetchMessages()
  }, [user, selected])
  const sendMessage = async () => {
    if (!user || !selected || newMsg.trim() === '') return
    const { error } = await supabase.from('messages').insert({
      sender_id: user.id,
      recipient_id: selected.id,
      message: newMsg.trim(),
    })
    if (error) setErrorMsg(error.message)
    else {
      setMessages((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          sender_id: user.id,
          recipient_id: selected.id,
          message: newMsg.trim(),
          created_at: new Date().toISOString(),
        },
      ])
      setNewMsg('')
    }
  }
  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-4xl mx-auto grid grid-cols-3 gap-4">
        {errorMsg && (
          <div className="col-span-3 text-red-500 mb-2">{errorMsg}</div>
        )}
        <div className="col-span-1 bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-3">Users</h3>
          <ul className="space-y-2">
            {otherUsers.map((u) => (
              <li key={u.id}>
                <button
                  onClick={() => setSelected(u)}
                  className={`w-full text-left p-2 rounded-md hover:bg-gray-100 ${selected?.id === u.id ? 'bg-gray-100' : ''}`}
                >
                  {u.profiles.full_name || u.profiles.username}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-span-2 bg-white p-4 rounded-lg shadow flex flex-col">
          <h3 className="text-lg font-semibold mb-3">
            {selected ? `Chat with ${selected.profiles.full_name || selected.profiles.username}` : 'Select a user to start chatting'}
          </h3>
          {selected && (
            <>
              <div className="flex-1 overflow-y-auto mb-3 border p-2 rounded-md">
                {messages.map((msg) => {
                  const isMine = msg.sender_id === user.id
                  return (
                    <div
                      key={msg.id}
                      className={`mb-2 flex ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`rounded-lg px-3 py-2 max-w-xs ${
                          isMine ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-900'
                        }`}
                      >
                        {msg.message}
                      </div>
                    </div>
                  )
                })}
              </div>
              <div className="flex">
                <input
                  type="text"
                  value={newMsg}
                  onChange={(e) => setNewMsg(e.target.value)}
                  className="flex-1 rounded-l-md border border-gray-300 p-2"
                  placeholder="Type a message"
                />
                <button
                  onClick={sendMessage}
                  className="rounded-r-md bg-indigo-600 text-white px-4"
                >
                  Send
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}