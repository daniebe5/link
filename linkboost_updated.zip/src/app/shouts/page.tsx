"use client"

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import dayjs from 'dayjs'
import relativeTime from 'dayjs/plugin/relativeTime'

dayjs.extend(relativeTime)

interface ShoutWithProfile {
  id: string
  content: string
  media_url: string | null
  expires_at: string
  created_at: string
  // Supabase returns joined rows as arrays by default. Use an array here.
  profiles: {
    full_name: string | null
    avatar_url: string | null
    username: string
  }[]
}

export default function PublicShoutsPage() {
  const [shouts, setShouts] = useState<ShoutWithProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  useEffect(() => {
    const fetchShouts = async () => {
      try {
        const now = dayjs().toISOString()
        const { data, error } = await supabase
          .from('shouts')
          .select('id,content,media_url,expires_at,created_at,profiles(full_name,avatar_url,username)')
          .gt('expires_at', now)
          .order('created_at', { ascending: false })
        if (error) throw error
        setShouts(data as ShoutWithProfile[])
      } catch (err) {
        // Handle unknown error types without using `any` to satisfy TypeScript
        // and ESLint rules. Convert the error to a readable message.
        if (err instanceof Error) {
          setErrorMsg(err.message)
        } else {
          setErrorMsg(String(err))
        }
      } finally {
        setLoading(false)
      }
    }
    fetchShouts()
  }, [])
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Public Shouts</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        {shouts.length === 0 ? (
          <p>No shouts available.</p>
        ) : (
          <div className="space-y-4">
            {shouts.map((shout) => (
              <div key={shout.id} className="bg-white p-4 rounded-md shadow">
                <div className="flex items-center mb-2">
                {(() => {
                  const profile = shout.profiles?.[0]
                  return (
                    <>
                      {profile?.avatar_url && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img
                          src={profile.avatar_url}
                          alt="avatar"
                          className="w-8 h-8 rounded-full mr-2 object-cover"
                        />
                      )}
                      <div>
                        {profile && (
                          <a
                            href={`/${profile.username}`}
                            className="font-semibold text-indigo-600 hover:underline"
                          >
                            {profile.full_name || profile.username}
                          </a>
                        )}
                        <p className="text-xs text-gray-500">
                          {dayjs(shout.created_at).fromNow()}
                        </p>
                      </div>
                    </>
                  )
                })()}
                </div>
                <p className="mb-2 whitespace-pre-wrap">{shout.content}</p>
                {shout.media_url && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={shout.media_url} alt="media" className="max-h-64 w-auto rounded-md mb-2" />
                )}
                <p className="text-xs text-gray-500">Expires {dayjs(shout.expires_at).fromNow(true)} left</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}