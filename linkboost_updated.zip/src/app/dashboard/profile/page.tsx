"use client"

import { useEffect, useState, ChangeEvent } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/providers/AuthProvider'

interface ProfileForm {
  full_name: string
  username: string
  bio: string
  profile_type: 'personal' | 'business'
  theme_background: string
  theme_button: string
  tiktok?: string
  instagram?: string
  youtube?: string
  linkedin?: string
}

interface ProfileRow extends ProfileForm {
  id: string
  user_id: string
  avatar_url: string | null
}

export default function EditProfilePage() {
  const { user } = useAuth()
  const router = useRouter()
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<ProfileForm>({
    defaultValues: {
      full_name: '',
      username: '',
      bio: '',
      profile_type: 'personal',
      theme_background: '#ffffff',
      theme_button: '#6366f1',
      tiktok: '',
      instagram: '',
      youtube: '',
      linkedin: '',
    },
  })
  const [profile, setProfile] = useState<ProfileRow | null>(null)
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)

  useEffect(() => {
    if (!user) return
    const fetchProfile = async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single()
      if (error && error.code !== 'PGRST116') {
        setErrorMsg(error.message)
      }
      if (data) {
        setProfile(data as ProfileRow)
        // set form values
        setValue('full_name', data.full_name ?? '')
        setValue('username', data.username ?? '')
        setValue('bio', data.bio ?? '')
        setValue('profile_type', (data.profile_type as 'personal' | 'business' | undefined) ?? 'personal')
        setValue('theme_background', data.theme_background ?? '#ffffff')
        setValue('theme_button', data.theme_button ?? '#6366f1')
        if (data.socials) {
          try {
            const socials = data.socials as Partial<{
              tiktok?: string | null
              instagram?: string | null
              youtube?: string | null
              linkedin?: string | null
            }>
            setValue('tiktok', socials.tiktok ?? '')
            setValue('instagram', socials.instagram ?? '')
            setValue('youtube', socials.youtube ?? '')
            setValue('linkedin', socials.linkedin ?? '')
          } catch {
            // ignore parse errors
          }
        }
      }
      setLoading(false)
    }
    fetchProfile()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  const handleAvatarChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAvatarFile(file)
      const url = URL.createObjectURL(file)
      setAvatarPreview(url)
    }
  }

  const uploadAvatar = async (file: File): Promise<string | null> => {
    const filePath = `${user!.id}/${Date.now()}_${file.name}`
    const { error } = await supabase.storage
      .from('avatars')
      .upload(filePath, file, { cacheControl: '3600', upsert: false })
    if (error) {
      setErrorMsg(error.message)
      return null
    }
    const { data } = supabase.storage.from('avatars').getPublicUrl(filePath)
    return data.publicUrl
  }

  const onSubmit = async (form: ProfileForm) => {
    if (!user) return
    setErrorMsg('')
    let avatarUrl = profile?.avatar_url ?? null
    if (avatarFile) {
      const uploaded = await uploadAvatar(avatarFile)
      if (uploaded) avatarUrl = uploaded
    }
    // assemble row
    const socials = {
      tiktok: form.tiktok || null,
      instagram: form.instagram || null,
      youtube: form.youtube || null,
      linkedin: form.linkedin || null,
    }
    try {
      if (profile) {
        // update existing row
        const { error } = await supabase
          .from('profiles')
          .update({
            full_name: form.full_name,
            username: form.username,
            bio: form.bio,
            profile_type: form.profile_type,
            theme_background: form.theme_background,
            theme_button: form.theme_button,
            avatar_url: avatarUrl,
            socials,
          })
          .eq('id', profile.id)
        if (error) throw error
      } else {
        // insert new profile
        const { error } = await supabase.from('profiles').insert({
          user_id: user.id,
          full_name: form.full_name,
          username: form.username,
          bio: form.bio,
          profile_type: form.profile_type,
          theme_background: form.theme_background,
          theme_button: form.theme_button,
          avatar_url: avatarUrl,
          socials,
        })
        if (error) throw error
      }
      router.push('/dashboard')
    } catch (error) {
      if (error instanceof Error) {
        setErrorMsg(error.message)
      }
    }
  }

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) {
    return <div className="p-6">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">{profile ? 'Edit' : 'Create'} Profile</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 mb-2 rounded-full bg-gray-200 overflow-hidden">
              {avatarPreview ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={avatarPreview} alt="Avatar preview" className="w-full h-full object-cover" />
              ) : profile?.avatar_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
              ) : null}
            </div>
            <input type="file" accept="image/*" onChange={handleAvatarChange} className="text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Full Name</label>
            <input
              type="text"
              {...register('full_name', { required: 'Full name is required' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
            {errors.full_name && <p className="text-red-500 text-xs mt-1">{errors.full_name.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Username</label>
            <input
              type="text"
              {...register('username', { required: 'Username is required' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
            {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Bio</label>
            <textarea
              {...register('bio')}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Profile Type</label>
            <select
              {...register('profile_type')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              <option value="personal">Personal</option>
              <option value="business">Business</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Background Color</label>
              <input
                type="color"
                {...register('theme_background')}
                className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Button Color</label>
              <input
                type="color"
                {...register('theme_button')}
                className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">TikTok</label>
              <input
                type="url"
                placeholder="https://www.tiktok.com/@username"
                {...register('tiktok')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Instagram</label>
              <input
                type="url"
                placeholder="https://instagram.com/username"
                {...register('instagram')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">YouTube</label>
              <input
                type="url"
                placeholder="https://youtube.com/channel/..."
                {...register('youtube')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">LinkedIn</label>
              <input
                type="url"
                placeholder="https://linkedin.com/in/username"
                {...register('linkedin')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}