import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function Profile() {
  const [bio, setBio] = useState('');
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Get the logged in user on mount
    const fetchUser = async () => {
      const {
        data: { user },
        error
      } = await supabase.auth.getUser();
      if (!error) setUser(user);
    };
    fetchUser();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!user) {
      alert('עליך להתחבר כדי לשמור פרופיל');
      return;
    }
    const updates = {
      id: user.id,
      bio,
      updated_at: new Date()
    };
    const { error } = await supabase.from('profiles').upsert(updates);
    if (error) {
      alert(`שגיאה בעדכון פרופיל: ${error.message}`);
    } else {
      alert('הפרופיל עודכן בהצלחה');
    }
  };
  return (
    <div className="max-w-2xl mx-auto p-4 mt-6 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">ערוך פרופיל</h2>
      <form onSubmit={handleSave} className="space-y-4">
        <div>
          <label className="block mb-1 text-sm">תמונה/לוגו</label>
          <input type="file" accept="image/*" className="w-full border px-3 py-2 rounded-md" />
        </div>
        <div>
          <label className="block mb-1 text-sm">תיאור קצר (Bio)</label>
          <textarea value={bio} onChange={(e) => setBio(e.target.value)} className="w-full border px-3 py-2 rounded-md" rows="3" />
        </div>
        <div>
          <label className="block mb-1 text-sm">צבע רקע</label>
          <input type="color" className="w-full h-12 border rounded-md" />
        </div>
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">שמור פרופיל</button>
      </form>
    </div>
  );
}