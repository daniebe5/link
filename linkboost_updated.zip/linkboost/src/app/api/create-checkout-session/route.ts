import Stripe from 'stripe'
import { NextRequest } from 'next/server'

// This API route is responsible for creating a Stripe Checkout session.  It
// expects a JSON body with a `priceId` property corresponding to a price
// identifier configured in your Stripe dashboard.  On success it returns
// the session ID to the client.

export async function POST(req: NextRequest) {
  const { priceId } = await req.json()
  if (!priceId) {
    return new Response(JSON.stringify({ error: 'Missing priceId' }), { status: 400 })
  }
  const stripeSecretKey = process.env.STRIPE_SECRET_KEY
  if (!stripeSecretKey) {
    return new Response(JSON.stringify({ error: 'Stripe secret key not configured' }), { status: 500 })
  }
  // Initialize Stripe without specifying an apiVersion to avoid type
  // mismatch errors that can occur when the @stripe/stripe-js version
  // expects a specific literal string. Omitting apiVersion uses Stripe's
  // default, which is acceptable for our use case.
  const stripe = new Stripe(stripeSecretKey)
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/pricing`,
    })
    return new Response(JSON.stringify({ id: session.id }), { status: 200 })
  } catch (error) {
    console.error(error)
    const message = error instanceof Error ? error.message : 'Unknown error'
    return new Response(JSON.stringify({ error: message }), { status: 500 })
  }
}