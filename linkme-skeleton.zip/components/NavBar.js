import Link from 'next/link';

export default function NavBar() {
  return (
    <header className="bg-white shadow">
      <nav className="container mx-auto flex items-center justify-between p-4">
        <Link href="/" className="text-xl font-bold">LinkMe</Link>
        <div className="space-x-4">
          <Link href="/profile" className="text-gray-700 hover:text-blue-600">פרופיל</Link>
          <Link href="/links" className="text-gray-700 hover:text-blue-600">קישורים</Link>
          <Link href="/shouts" className="text-gray-700 hover:text-blue-600">Shouts</Link>
          <Link href="/analytics" className="text-gray-700 hover:text-blue-600">אנליטיקה</Link>
          <Link href="/search" className="text-gray-700 hover:text-blue-600">חיפוש</Link>
          <Link href="/pricing" className="text-gray-700 hover:text-blue-600">תמחור</Link>
        </div>
      </nav>
    </header>
  );
}