"use client"

import { useEffect, useState, ChangeEvent } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import * as db from '@/lib/localDb'
import { useAuth } from '@/providers/AuthProvider'
import type { Profile as LocalProfile } from '@/lib/localDb'

interface ProfileForm {
  full_name: string
  username: string
  bio: string
  profile_type: 'personal' | 'business'
  theme_background: string
  theme_button: string
  tiktok?: string
  instagram?: string
  youtube?: string
  linkedin?: string
}

interface ProfileRow extends ProfileForm {
  id: string
  user_id: string
  avatar_url: string | null
}

export default function EditProfilePage() {
  const { user } = useAuth()
  const router = useRouter()
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<ProfileForm>({
    defaultValues: {
      full_name: '',
      username: '',
      bio: '',
      profile_type: 'personal',
      theme_background: '#ffffff',
      theme_button: '#6366f1',
      tiktok: '',
      instagram: '',
      youtube: '',
      linkedin: '',
    },
  })
  const [profile, setProfile] = useState<ProfileRow | null>(null)
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)

  useEffect(() => {
    if (!user) return
    // Fetch profile from localDb on mount
    const p = db.getProfile(user.id)
    if (p) {
      // convert to our form shape
      setProfile({
        id: p.id,
        user_id: p.userId,
        avatar_url: p.avatarUrl,
        full_name: p.fullName ?? '',
        username: p.username ?? '',
        bio: p.bio ?? '',
        profile_type: p.profileType ?? 'personal',
        theme_background: p.themeBackground ?? '#ffffff',
        theme_button: p.themeButton ?? '#6366f1',
        tiktok: p.socials?.tiktok ?? '',
        instagram: p.socials?.instagram ?? '',
        youtube: p.socials?.youtube ?? '',
        linkedin: p.socials?.linkedin ?? '',
      })
      setValue('full_name', p.fullName ?? '')
      setValue('username', p.username ?? '')
      setValue('bio', p.bio ?? '')
      setValue('profile_type', (p.profileType as 'personal' | 'business' | undefined) ?? 'personal')
      setValue('theme_background', p.themeBackground ?? '#ffffff')
      setValue('theme_button', p.themeButton ?? '#6366f1')
      setValue('tiktok', p.socials?.tiktok ?? '')
      setValue('instagram', p.socials?.instagram ?? '')
      setValue('youtube', p.socials?.youtube ?? '')
      setValue('linkedin', p.socials?.linkedin ?? '')
      if (p.avatarUrl) {
        setAvatarPreview(p.avatarUrl)
      }
    }
    setLoading(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  const handleAvatarChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setAvatarFile(file)
      const url = URL.createObjectURL(file)
      setAvatarPreview(url)
    }
  }

  // Convert a file to a Data URL. This helper is used to read the avatar
  // locally without uploading to a remote server.
  const fileToDataURL = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => {
        resolve(reader.result as string)
      }
      reader.onerror = reject
      reader.readAsDataURL(file)
    })

  const onSubmit = async (form: ProfileForm) => {
    if (!user) return
    setErrorMsg('')
    // Determine the avatar URL: existing preview or newly selected file
    let avatarUrl: string | null = profile?.avatar_url ?? null
    if (avatarFile) {
      try {
        avatarUrl = await fileToDataURL(avatarFile)
      } catch (err) {
        avatarUrl = null
      }
    }
    const socials = {
      tiktok: form.tiktok || null,
      instagram: form.instagram || null,
      youtube: form.youtube || null,
      linkedin: form.linkedin || null,
    }
    try {
      // Generate a profile object compatible with localDb
      const newProfile: LocalProfile = {
        id: profile?.id || (Date.now().toString(36) + Math.random().toString(36).substring(2)),
        userId: user.id,
        username: form.username,
        fullName: form.full_name,
        bio: form.bio,
        profileType: form.profile_type,
        themeBackground: form.theme_background,
        themeButton: form.theme_button,
        avatarUrl: avatarUrl,
        socials,
      }
      db.upsertProfile(newProfile)
      router.push('/dashboard')
    } catch (error) {
      if (error instanceof Error) {
        setErrorMsg(error.message)
      }
    }
  }

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) {
    return <div className="p-6">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">{profile ? 'Edit' : 'Create'} Profile</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 mb-2 rounded-full bg-gray-200 overflow-hidden">
              {avatarPreview ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={avatarPreview} alt="Avatar preview" className="w-full h-full object-cover" />
              ) : profile?.avatar_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={profile.avatar_url} alt="Avatar" className="w-full h-full object-cover" />
              ) : null}
            </div>
            <input type="file" accept="image/*" onChange={handleAvatarChange} className="text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Full Name</label>
            <input
              type="text"
              {...register('full_name', { required: 'Full name is required' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
            {errors.full_name && <p className="text-red-500 text-xs mt-1">{errors.full_name.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Username</label>
            <input
              type="text"
              {...register('username', { required: 'Username is required' })}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
            {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username.message}</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Bio</label>
            <textarea
              {...register('bio')}
              rows={3}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Profile Type</label>
            <select
              {...register('profile_type')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
            >
              <option value="personal">Personal</option>
              <option value="business">Business</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Background Color</label>
              <input
                type="color"
                {...register('theme_background')}
                className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Button Color</label>
              <input
                type="color"
                {...register('theme_button')}
                className="mt-1 block w-full h-10 rounded-md border-gray-300 shadow-sm"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">TikTok</label>
              <input
                type="url"
                placeholder="https://www.tiktok.com/@username"
                {...register('tiktok')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Instagram</label>
              <input
                type="url"
                placeholder="https://instagram.com/username"
                {...register('instagram')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">YouTube</label>
              <input
                type="url"
                placeholder="https://youtube.com/channel/..."
                {...register('youtube')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">LinkedIn</label>
              <input
                type="url"
                placeholder="https://linkedin.com/in/username"
                {...register('linkedin')}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}