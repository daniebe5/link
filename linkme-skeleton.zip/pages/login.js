import { useState } from 'react';
import Link from 'next/link';
import { supabase } from '../lib/supabaseClient';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    // Use Supabase Auth to sign in the user
    supabase
      .auth
      .signInWithPassword({ email, password })
      .then(({ data, error }) => {
        if (error) {
          alert(`שגיאה בהתחברות: ${error.message}`);
        } else {
          alert('התחברת בהצלחה!');
        }
      });
  };
  return (
    <div className="max-w-md mx-auto p-4 mt-10 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">התחברות</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 text-sm">אימייל</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <div>
          <label className="block mb-1 text-sm">סיסמה</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">התחבר</button>
      </form>
      <p className="mt-4 text-sm text-center">
        אין לך חשבון? <Link href="/signup" className="text-blue-600 hover:underline">צור חשבון כאן</Link>
      </p>
    </div>
  );
}