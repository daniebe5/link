"use client"

import { useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useAuth } from '@/providers/AuthProvider'
import { useRouter } from 'next/navigation'

export default function SettingsPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [newPassword, setNewPassword] = useState('')
  const [message, setMessage] = useState('')
  const [errorMsg, setErrorMsg] = useState('')
  const handlePasswordChange = async () => {
    setMessage('')
    setErrorMsg('')
    const { error } = await supabase.auth.updateUser({ password: newPassword })
    if (error) setErrorMsg(error.message)
    else {
      setMessage('Password updated successfully')
      setNewPassword('')
    }
  }
  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push('/login')
  }
  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-xl mx-auto bg-white p-6 rounded-lg shadow">
        <h2 className="text-2xl font-bold mb-4">Account Settings</h2>
        {errorMsg && <p className="text-red-500 mb-2">{errorMsg}</p>}
        {message && <p className="text-green-600 mb-2">{message}</p>}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700">Change Password</label>
          <input
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
          <button
            onClick={handlePasswordChange}
            className="mt-2 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Update Password
          </button>
        </div>
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700">Language (placeholder)</label>
          <select className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
            <option value="en">English</option>
            <option value="he">Hebrew</option>
            <option value="ar">Arabic</option>
          </select>
        </div>
        <div>
          <button
            onClick={handleSignOut}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  )
}