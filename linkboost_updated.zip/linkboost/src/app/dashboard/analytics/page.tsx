"use client"

import { useEffect, useState } from 'react'
// Import functions from our local storage database.  These helpers provide
// client‑side equivalents to the Supabase queries previously used.
import { getLinks, getClickCountsForUser } from '@/lib/localDb'
import { useAuth } from '@/providers/AuthProvider'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface ChartData {
  name: string
  clicks: number
}

export default function AnalyticsPage() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  const [chartData, setChartData] = useState<ChartData[]>([])

  useEffect(() => {
    if (!user) return
    const fetchAnalytics = async () => {
      try {
        // Fetch the user's links and click counts from local storage.  We do not
        // call any external APIs here; everything is stored in the browser.
        const links = getLinks(user.id)
        if (links.length === 0) {
          setChartData([])
          return
        }
        const counts = getClickCountsForUser(user.id)
        const data: ChartData[] = links.map((link) => ({
          name: link.title,
          clicks: counts[link.id] || 0,
        }))
        setChartData(data)
      } catch (err) {
        if (err instanceof Error) {
          setErrorMsg(err.message)
        } else {
          setErrorMsg(String(err))
        }
      } finally {
        setLoading(false)
      }
    }
    fetchAnalytics()
  }, [user])

  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }

  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Analytics</h2>
        {errorMsg && <p className="text-red-500 mb-4">{errorMsg}</p>}
        {chartData.length === 0 ? (
          <p>No data available yet. Share your profile to start gathering clicks!</p>
        ) : (
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Clicks per Link</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" interval={0} angle={-45} textAnchor="end" height={70} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="clicks" />
              </BarChart>
            </ResponsiveContainer>
            <table className="min-w-full divide-y divide-gray-200 mt-4">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Link
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Clicks
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {chartData.map((row) => (
                  <tr key={row.name}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{row.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 text-right">
                      {row.clicks}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}