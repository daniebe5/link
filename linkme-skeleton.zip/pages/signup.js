import { useState } from 'react';
import Link from 'next/link';
import { supabase } from '../lib/supabaseClient';

export default function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    // Use Supabase Auth to sign up the user
    supabase
      .auth
      .signUp({
        email,
        password,
        options: {
          data: { full_name: name }
        }
      })
      .then(({ data, error }) => {
        if (error) {
          alert(`שגיאה בהרשמה: ${error.message}`);
        } else {
          alert('נשלח מייל אימות. אנא בדוק את תיבת הדואר שלך.');
        }
      });
  };
  return (
    <div className="max-w-md mx-auto p-4 mt-10 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">הרשמה</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1 text-sm">שם מלא</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <div>
          <label className="block mb-1 text-sm">אימייל</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <div>
          <label className="block mb-1 text-sm">סיסמה</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full border px-3 py-2 rounded-md" required />
        </div>
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">צור חשבון</button>
      </form>
      <p className="mt-4 text-sm text-center">
        כבר יש לך חשבון? <Link href="/login" className="text-blue-600 hover:underline">התחבר כאן</Link>
      </p>
    </div>
  );
}