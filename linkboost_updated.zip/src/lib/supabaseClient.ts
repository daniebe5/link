import { createClient } from '@supabase/supabase-js'

// Initialize a Supabase client using environment variables.  The public URL and
// anonymous key should be defined in your `.env.local` file.  See
// `.env.local.example` at the project root for guidance.  Without these
// environment variables populated the Supabase client will still be
// instantiated, but API requests will fail.  See the README for more
// information about obtaining these credentials from the Supabase dashboard.

// Provide fallback values for the Supabase URL and anon key.  Without these
// values the `createClient` call will throw at build time (e.g., during
// prerendering) because Supabase requires a URL.  These placeholder
// values will not allow authenticated requests, but they enable the
// application to compile successfully.  At runtime you should provide
// real values via environment variables in `.env.local`.
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co'
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'public-anon-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)