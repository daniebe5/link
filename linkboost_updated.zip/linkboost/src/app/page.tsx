"use client"

import Link from 'next/link'
import { useAuth } from '@/providers/AuthProvider'

export default function HomePage() {
  const { user } = useAuth()
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4 py-20 text-center">
      <h1 className="text-5xl font-extrabold mb-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-transparent bg-clip-text">
        LinkBoost
      </h1>
      <p className="text-lg text-gray-600 max-w-2xl mb-6">
        Build a beautiful link-in-bio profile, share updates with your followers, track analytics, chat with fans, and grow your personal or business brand.
      </p>
      {user ? (
        <Link
          href="/dashboard"
          className="inline-block mt-4 px-6 py-3 rounded-md text-white bg-indigo-600 hover:bg-indigo-700 transition"
        >
          Go to Dashboard
        </Link>
      ) : (
        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            href="/signup"
            className="inline-block px-6 py-3 rounded-md text-white bg-indigo-600 hover:bg-indigo-700 transition"
          >
            Get Started
          </Link>
          <Link
            href="/login"
            className="inline-block px-6 py-3 rounded-md text-indigo-600 bg-white border border-indigo-600 hover:bg-indigo-50 transition"
          >
            Sign In
          </Link>
        </div>
      )}
      <div className="mt-8 flex flex-col sm:flex-row gap-4">
        <Link
          href="/explore"
          className="text-indigo-600 hover:underline"
        >
          Explore creators
        </Link>
        <Link
          href="/pricing"
          className="text-indigo-600 hover:underline"
        >
          View pricing
        </Link>
      </div>
    </div>
  )
}