export default function Pricing() {
  return (
    <div className="max-w-4xl mx-auto p-4 mt-6">
      <h2 className="text-2xl font-semibold mb-4 text-center">תוכניות תמחור</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="border p-4 rounded-md shadow-sm">
          <h3 className="text-xl font-semibold mb-2">Free</h3>
          <p className="mb-4 text-gray-600">תוכנית בסיסית לניהול קישורים.</p>
          <ul className="mb-4 list-disc list-inside text-gray-700">
            <li>מספר קישורים מוגבל</li>
            <li>קישור QR קוד אוטומטי</li>
            <li>פרסום מודעות</li>
          </ul>
          <button className="w-full bg-blue-600 text-white py-2 rounded-md">הירשם</button>
        </div>
        <div className="border p-4 rounded-md shadow-sm">
          <h3 className="text-xl font-semibold mb-2">Pro</h3>
          <p className="mb-4 text-gray-600">תוכנית מתקדמת הכוללת אנליטיקות.</p>
          <ul className="mb-4 list-disc list-inside text-gray-700">
            <li>כל מה שיש ב‑Free</li>
            <li>אנליטיקות מתקדמות</li>
            <li>הסרת פרסומות</li>
          </ul>
          <button className="w-full bg-blue-600 text-white py-2 rounded-md">בחר תוכנית</button>
        </div>
        <div className="border p-4 rounded-md shadow-sm">
          <h3 className="text-xl font-semibold mb-2">Business</h3>
          <p className="mb-4 text-gray-600">תוכנית לעסקים עם יכולות מתקדמות.</p>
          <ul className="mb-4 list-disc list-inside text-gray-700">
            <li>כל מה שיש ב‑Pro</li>
            <li>מספר פרופילים מרובים</li>
            <li>תמיכה עדיפות</li>
          </ul>
          <button className="w-full bg-blue-600 text-white py-2 rounded-md">בחר תוכנית</button>
        </div>
      </div>
    </div>
  );
}