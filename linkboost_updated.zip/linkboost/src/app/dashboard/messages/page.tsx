"use client"

import { useEffect, useState } from 'react'
// Use localDb helpers for messages, profiles, and users.  This eliminates
// external dependencies and stores all messages in localStorage.
import { getAllProfiles, getConversation, addMessage } from '@/lib/localDb'
import { useAuth } from '@/providers/AuthProvider'

interface UserRow {
  id: string
  profile: {
    username: string
    fullName: string
    avatarUrl: string | null
  }
}
interface MessageRow {
  id: string
  senderId: string
  recipientId: string
  message: string
  createdAt: number
}

export default function MessagesPage() {
  const { user } = useAuth()
  const [otherUsers, setOtherUsers] = useState<UserRow[]>([])
  const [selected, setSelected] = useState<UserRow | null>(null)
  const [messages, setMessages] = useState<MessageRow[]>([])
  const [newMsg, setNewMsg] = useState('')
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState('')
  useEffect(() => {
    if (!user) return
    // Load all profiles from local storage except the current user's.  Only
    // users who have created profiles will appear here.
    const profiles = getAllProfiles().filter((p) => p.userId !== user.id)
    setOtherUsers(
      profiles.map((p) => ({
        id: p.userId,
        profile: {
          username: p.username,
          fullName: p.fullName,
          avatarUrl: p.avatarUrl,
        },
      }))
    )
    setLoading(false)
  }, [user])

  useEffect(() => {
    if (!user || !selected) return
    // Load conversation from local storage for the selected user.  This
    // returns messages sorted by createdAt.
    const msgs = getConversation(user.id, selected.id)
    // Transform into our MessageRow shape
    setMessages(
      msgs.map((m) => ({
        id: m.id,
        senderId: m.senderId,
        recipientId: m.recipientId,
        message: m.message,
        createdAt: m.createdAt,
      }))
    )
  }, [user, selected])
  const sendMessage = async () => {
    if (!user || !selected || newMsg.trim() === '') return
    // Append a new message to local storage and update state.  Errors
    // thrown by addMessage are ignored here.
    addMessage(user.id, selected.id, newMsg.trim())
    setMessages((prev) => [
      ...prev,
      {
        id: Math.random().toString(),
        senderId: user.id,
        recipientId: selected.id,
        message: newMsg.trim(),
        createdAt: Date.now(),
      },
    ])
    setNewMsg('')
  }
  if (!user) {
    return (
      <div className="p-6">
        <h2 className="text-xl font-semibold">Please sign in</h2>
      </div>
    )
  }
  if (loading) return <div className="p-6">Loading...</div>
  return (
    <div className="min-h-screen bg-gray-100 py-10 px-4">
      <div className="max-w-4xl mx-auto grid grid-cols-3 gap-4">
        {errorMsg && (
          <div className="col-span-3 text-red-500 mb-2">{errorMsg}</div>
        )}
        <div className="col-span-1 bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-3">Users</h3>
          <ul className="space-y-2">
            {otherUsers.map((u) => (
              <li key={u.id}>
                <button
                  onClick={() => setSelected(u)}
                  className={`w-full text-left p-2 rounded-md hover:bg-gray-100 ${selected?.id === u.id ? 'bg-gray-100' : ''}`}
                >
                  {u.profile.fullName || u.profile.username}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-span-2 bg-white p-4 rounded-lg shadow flex flex-col">
          <h3 className="text-lg font-semibold mb-3">
            {selected ? `Chat with ${selected.profile.fullName || selected.profile.username}` : 'Select a user to start chatting'}
          </h3>
          {selected && (
            <>
              <div className="flex-1 overflow-y-auto mb-3 border p-2 rounded-md">
                {messages.map((msg) => {
                  const isMine = msg.senderId === user.id
                  return (
                    <div
                      key={msg.id}
                      className={`mb-2 flex ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`rounded-lg px-3 py-2 max-w-xs ${
                          isMine ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-900'
                        }`}
                      >
                        {msg.message}
                      </div>
                    </div>
                  )
                })}
              </div>
              <div className="flex">
                <input
                  type="text"
                  value={newMsg}
                  onChange={(e) => setNewMsg(e.target.value)}
                  className="flex-1 rounded-l-md border border-gray-300 p-2"
                  placeholder="Type a message"
                />
                <button
                  onClick={sendMessage}
                  className="rounded-r-md bg-indigo-600 text-white px-4"
                >
                  Send
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}