import { useState } from 'react';

export default function Search() {
  const [query, setQuery] = useState('');
  const handleSearch = (e) => {
    e.preventDefault();
    alert(`חיפוש עבור: ${query}`);
  };
  return (
    <div className="max-w-md mx-auto p-4 mt-6 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">חיפוש משתמשים</h2>
      <form onSubmit={handleSearch} className="space-y-4">
        <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="חפש שם משתמש, תחום עניין..." className="w-full border px-3 py-2 rounded-md" />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">חפש</button>
      </form>
    </div>
  );
}