import { useState } from 'react';

export default function Shouts() {
  const [shouts, setShouts] = useState([]);
  const [content, setContent] = useState('');
  const handleAdd = (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    setShouts([{ content, timestamp: new Date() }, ...shouts]);
    setContent('');
  };
  return (
    <div className="max-w-xl mx-auto p-4 mt-6 bg-white rounded-md shadow-md">
      <h2 className="text-2xl font-semibold mb-4">Shouts</h2>
      <form onSubmit={handleAdd} className="space-y-4">
        <textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="כתוב משהו..." className="w-full border px-3 py-2 rounded-md" rows="3" />
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">פרסם Shout</button>
      </form>
      <ul className="space-y-4 mt-6">
        {shouts.map((shout, index) => (
          <li key={index} className="border p-3 rounded-md">
            <p>{shout.content}</p>
            <span className="text-xs text-gray-500">{shout.timestamp.toLocaleString()}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}